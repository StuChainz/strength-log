import { fireEvent, render, waitFor } from '@testing-library/react-native';
import App from '../../App';
import { openDb } from '@/db/client';
import { getAppSettings, setAppSetting } from '@/db/repositories/settings.repo';

jest.mock('react-native-safe-area-context', () => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const React = require('react');
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { View } = require('react-native');
  const insets = { top: 0, right: 0, bottom: 0, left: 0 };
  const frame = { x: 0, y: 0, width: 390, height: 844 };

  return {
    SafeAreaProvider: ({ children }: { children: React.ReactNode }) =>
      React.createElement(View, null, children),
    SafeAreaView: ({ children }: { children: React.ReactNode }) =>
      React.createElement(View, null, children),
    SafeAreaInsetsContext: React.createContext(insets),
    SafeAreaFrameContext: React.createContext(frame),
    initialWindowMetrics: { insets, frame },
    useSafeAreaInsets: () => insets,
    useSafeAreaFrame: () => frame,
  };
});

jest.mock('@/db/client', () => ({
  openDb: jest.fn(),
}));

jest.mock('@/db/repositories/settings.repo', () => ({
  getAppSettings: jest.fn(),
  setAppSetting: jest.fn(),
}));

jest.mock('@/notifications/restTimerNotifications', () => ({
  registerRestTimerNotificationNavigation: jest.fn(() => jest.fn()),
}));

jest.mock('@/db/repositories/templates.repo', () => ({
  getActiveProgramPresetId: jest.fn().mockResolvedValue(null),
  getNormalTemplatesWithCount: jest.fn().mockResolvedValue([]),
}));

jest.mock('@/db/repositories/sessions.repo', () => ({
  getInProgressSession: jest.fn().mockResolvedValue(null),
  getSessionRecovery: jest.fn().mockResolvedValue({ status: 'none', sessions: [] }),
}));

jest.mock('@/db/repositories/tags.repo', () => ({
  getUntaggedCompletedSession: jest.fn().mockResolvedValue(null),
}));

jest.mock('@/db/repositories/insights.repo', () => ({
  maybeGenerateWeeklyInsight: jest.fn().mockResolvedValue(null),
  getAllInsightCards: jest.fn().mockResolvedValue([]),
}));

jest.mock('@/db/repositories/exercises.repo', () => ({
  getExerciseLibraryDiagnostics: jest.fn().mockResolvedValue(null),
  getExercisesWithMetadata: jest.fn().mockResolvedValue([]),
}));

describe('App startup', () => {
  const openDbMock = openDb as jest.MockedFunction<typeof openDb>;
  const getAppSettingsMock = getAppSettings as jest.MockedFunction<typeof getAppSettings>;
  const setAppSettingMock = setAppSetting as jest.MockedFunction<typeof setAppSetting>;
  const mockDb = {} as Awaited<ReturnType<typeof openDb>>;

  beforeEach(() => {
    jest.clearAllMocks();
    openDbMock.mockReset();
    openDbMock.mockResolvedValue(mockDb);
    getAppSettingsMock.mockResolvedValue({
      unit: 'kg',
      weekStartDay: 'monday',
      voiceMode: false,
      onboardingCompleted: true,
    });
    setAppSettingMock.mockResolvedValue(undefined);
  });

  it('renders the first screen instead of a blank root', async () => {
    const { getByText } = render(<App />);

    await waitFor(() => expect(getByText('Start Workout')).toBeTruthy());
  });

  it('shows onboarding on first launch', async () => {
    getAppSettingsMock.mockResolvedValueOnce({
      unit: 'kg',
      weekStartDay: 'monday',
      voiceMode: false,
      onboardingCompleted: false,
    });

    const { getByText } = render(<App />);

    await waitFor(() =>
      expect(getByText('Fast, local-first strength training logging.')).toBeTruthy(),
    );
    expect(getByText('Get Started')).toBeTruthy();
  });

  it('introduces the main app features during onboarding', async () => {
    getAppSettingsMock.mockResolvedValueOnce({
      unit: 'kg',
      weekStartDay: 'monday',
      voiceMode: false,
      onboardingCompleted: false,
    });

    const { getByText } = render(<App />);

    await waitFor(() => expect(getByText('Get Started')).toBeTruthy());
    fireEvent.press(getByText('Get Started'));

    expect(getByText('Build Your Training')).toBeTruthy();
    expect(getByText('Create custom exercises')).toBeTruthy();
    expect(getByText('Build and edit templates')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Log A Live Workout')).toBeTruthy();
    expect(getByText('Edit, delete, or undo sets')).toBeTruthy();
    expect(getByText('Use the rest timer between sets')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Use Your History')).toBeTruthy();
    expect(getByText('Use conservative next-set suggestions')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Never Lose A Workout')).toBeTruthy();
    expect(getByText('Keep an append-only event log')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Finish With A Clear Summary')).toBeTruthy();
    expect(getByText('Best Lift')).toBeTruthy();
    expect(getByText('Grouped PRs')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Add Context')).toBeTruthy();
    expect(getByText('Post-session tags')).toBeTruthy();
    expect(getByText('Energy rating')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Review Progress')).toBeTruthy();
    expect(getByText('Weekly insight card')).toBeTruthy();
    expect(getByText('JSON export')).toBeTruthy();
    fireEvent.press(getByText('Next'));

    expect(getByText('Typed voice commands are optional')).toBeTruthy();
    expect(getByText('Start Logging')).toBeTruthy();
  });

  it('persists onboarding completion and navigates to Home', async () => {
    getAppSettingsMock.mockResolvedValueOnce({
      unit: 'kg',
      weekStartDay: 'monday',
      voiceMode: false,
      onboardingCompleted: false,
    });

    const { getByText } = render(<App />);

    await waitFor(() => expect(getByText('Get Started')).toBeTruthy());
    fireEvent.press(getByText('Get Started'));
    for (let step = 0; step < 7; step += 1) {
      fireEvent.press(getByText('Next'));
    }
    fireEvent.press(getByText('Start Logging'));

    await waitFor(() =>
      expect(setAppSettingMock).toHaveBeenCalledWith(mockDb, 'onboardingCompleted', true),
    );
    await waitFor(() => expect(getByText('Start Workout')).toBeTruthy());
  });

  it('skips onboarding for returning users', async () => {
    const { getByText, queryByText } = render(<App />);

    await waitFor(() => expect(getByText('Start Workout')).toBeTruthy());
    expect(queryByText('Fast, local-first strength training logging.')).toBeNull();
  });

  it('does not render navigation until database startup completes', async () => {
    let resolveOpenDb: (value: Awaited<ReturnType<typeof openDb>>) => void = () => {};
    openDbMock.mockReturnValueOnce(
      new Promise((resolve) => {
        resolveOpenDb = resolve;
      }),
    );

    const { getByText, queryByText } = render(<App />);

    expect(getByText('Starting Set')).toBeTruthy();
    expect(queryByText('Start Workout')).toBeNull();

    resolveOpenDb(mockDb);

    await waitFor(() => expect(getByText('Start Workout')).toBeTruthy());
  });

  it('shows a retry state when database startup fails', async () => {
    const consoleError = jest.spyOn(console, 'error').mockImplementation(() => {});
    openDbMock.mockRejectedValueOnce(new Error('migration failed')).mockResolvedValueOnce(mockDb);

    try {
      const { getByText } = render(<App />);

      await waitFor(() => expect(getByText('Set could not start')).toBeTruthy());
      expect(openDbMock).toHaveBeenCalledTimes(1);
      fireEvent.press(getByText('Try Again'));

      await waitFor(() => expect(getByText('Start Workout')).toBeTruthy());
      expect(openDbMock.mock.results[0]?.type).toBe('return');
      expect(openDbMock.mock.results[1]?.type).toBe('return');
    } finally {
      consoleError.mockRestore();
    }
  });
});
