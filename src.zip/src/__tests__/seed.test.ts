import { SEED_EXERCISES, SEED_EXERCISE_METADATA } from '@/db/seed/exercises';
import {
  auditExerciseMetadataFixture,
  summarizeExerciseMetadataCoverage,
  summarizeExerciseMetadataSubstitutionGroups,
} from '@/domain/exerciseMetadataFixtureAudit';
import { normalizeName } from '@/domain/ids';
import { ExerciseMetadataInputSchema } from '@/domain/validation';
import type { BodyRegion, ForceType, MovementPattern } from '@/domain/types';

const REQUIRED_METADATA_MOVEMENT_PATTERNS: MovementPattern[] = [
  'horizontal_push',
  'vertical_push',
  'horizontal_pull',
  'vertical_pull',
  'squat',
  'hinge',
  'lunge',
  'hip_extension',
  'elbow_flexion',
  'elbow_extension',
  'shoulder_abduction',
  'core',
];

const REQUIRED_METADATA_FORCE_TYPES: ForceType[] = ['push', 'pull', 'legs', 'hinge', 'core'];

describe('SEED_EXERCISES', () => {
  it('contains a curated beta-sized exercise library', () => {
    expect(SEED_EXERCISES.length).toBeGreaterThanOrEqual(120);
    expect(SEED_EXERCISES.length).toBeLessThanOrEqual(180);
  });

  it('every exercise has a non-empty name', () => {
    SEED_EXERCISES.forEach((e) => {
      expect(e.name.trim().length).toBeGreaterThan(0);
    });
  });

  it('every exercise has a valid category', () => {
    const valid = new Set(['barbell', 'dumbbell', 'machine', 'bodyweight', 'cable', 'other']);
    SEED_EXERCISES.forEach((e) => {
      expect(valid.has(e.category)).toBe(true);
    });
  });

  it('all exercise names are unique after normalisation', () => {
    const seen = new Set<string>();
    const duplicates: string[] = [];

    SEED_EXERCISES.forEach((exercise) => {
      const normalised = normalizeName(exercise.name);
      if (seen.has(normalised)) {
        duplicates.push(exercise.name);
      }
      seen.add(normalised);
    });

    expect(duplicates).toEqual([]);
  });

  it('every exercise has a primary muscle for list summaries and filtering', () => {
    SEED_EXERCISES.forEach((exercise) => {
      expect(exercise.primary_muscle?.trim().length).toBeGreaterThan(0);
    });
  });

  it('every exercise has at least one alias', () => {
    SEED_EXERCISES.forEach((e) => {
      expect(e.aliases.length).toBeGreaterThanOrEqual(1);
    });
  });

  it('all aliases are globally unique after normalisation', () => {
    const seen = new Set<string>();
    const duplicates: string[] = [];

    SEED_EXERCISES.forEach((exercise) => {
      exercise.aliases.forEach((alias) => {
        const normalised = normalizeName(alias);
        if (seen.has(normalised)) {
          duplicates.push(`${normalised} (in "${exercise.name}")`);
        }
        seen.add(normalised);
      });
    });

    expect(duplicates).toEqual([]);
  });

  it('covers barbell, dumbbell, bodyweight, machine, and cable categories', () => {
    const categories = new Set(SEED_EXERCISES.map((e) => e.category));
    expect(categories.has('barbell')).toBe(true);
    expect(categories.has('dumbbell')).toBe(true);
    expect(categories.has('bodyweight')).toBe(true);
    expect(categories.has('machine')).toBe(true);
    expect(categories.has('cable')).toBe(true);
  });
});

describe('SEED_EXERCISE_METADATA', () => {
  it('has complete metadata for every curated seed exercise', () => {
    expect(SEED_EXERCISE_METADATA).toHaveLength(SEED_EXERCISES.length);
  });

  it('only references existing seed exercises by name', () => {
    const exerciseNames = new Set(SEED_EXERCISES.map((e) => e.name));

    SEED_EXERCISE_METADATA.forEach((metadata) => {
      expect(exerciseNames.has(metadata.exerciseName)).toBe(true);
    });
  });

  it('uses a unique stable source_id for every metadata entry', () => {
    const seen = new Set<string>();
    const duplicates: string[] = [];

    SEED_EXERCISE_METADATA.forEach((metadata) => {
      if (seen.has(metadata.source_id)) {
        duplicates.push(metadata.source_id);
      }
      seen.add(metadata.source_id);
    });

    expect(duplicates).toEqual([]);
  });

  it('covers the required movement patterns', () => {
    const patterns = new Set(SEED_EXERCISE_METADATA.map((m) => m.movement_pattern));

    REQUIRED_METADATA_MOVEMENT_PATTERNS.forEach((pattern) => {
      expect(patterns.has(pattern)).toBe(true);
    });
  });

  it('covers Push, Pull, Legs, Hinge, and Core filters', () => {
    const forceTypes = new Set(SEED_EXERCISE_METADATA.map((m) => m.force_type));

    REQUIRED_METADATA_FORCE_TYPES.forEach((forceType) => {
      expect(forceTypes.has(forceType)).toBe(true);
    });
  });

  it('covers practical body regions for library filtering', () => {
    const regions = new Set(SEED_EXERCISE_METADATA.map((m) => m.body_region));

    const requiredRegions: BodyRegion[] = ['upper_body', 'lower_body', 'full_body', 'core'];

    requiredRegions.forEach((region) => {
      expect(regions.has(region)).toBe(true);
    });
  });

  it('matches the exercise metadata validation schema', () => {
    SEED_EXERCISE_METADATA.forEach(({ exerciseName, ...metadata }) => {
      expect(() => ExerciseMetadataInputSchema.parse(metadata)).not.toThrow();
      expect(exerciseName.trim().length).toBeGreaterThan(0);
    });
  });

  it('passes the offline fixture audit for future import readiness', () => {
    const audit = auditExerciseMetadataFixture(SEED_EXERCISES, SEED_EXERCISE_METADATA, {
      requiredMovementPatterns: REQUIRED_METADATA_MOVEMENT_PATTERNS,
      requiredForceTypes: REQUIRED_METADATA_FORCE_TYPES,
    });

    expect(audit.issues).toEqual([]);
    expect(audit.ok).toBe(true);
    expect(audit.counts.metadata).toBe(SEED_EXERCISE_METADATA.length);
  });

  it('summarizes complete metadata coverage for the beta seed phase', () => {
    const coverage = summarizeExerciseMetadataCoverage(SEED_EXERCISES, SEED_EXERCISE_METADATA);

    expect(coverage.totalExercises).toBe(SEED_EXERCISES.length);
    expect(coverage.annotatedExercises).toBe(SEED_EXERCISE_METADATA.length);
    expect(coverage.unannotatedExercises).toBe(0);
    expect(coverage.unannotated).toEqual([]);
  });

  it('summarizes substitution groups for later substitution curation', () => {
    const summary = summarizeExerciseMetadataSubstitutionGroups(SEED_EXERCISE_METADATA);
    const multiExerciseGroupNames = summary.multiExerciseGroups.map((group) => group.group);
    const singletonGroupNames = summary.singletonGroups.map((group) => group.group);

    expect(multiExerciseGroupNames).toEqual(
      expect.arrayContaining([
        'core_anti_extension',
        'horizontal_press',
        'horizontal_row',
        'vertical_pull',
      ]),
    );
    expect(singletonGroupNames).toContain('good_morning');
    expect(summary.groups.length).toBeGreaterThan(summary.multiExerciseGroups.length);
  });
});
