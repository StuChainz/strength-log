// SQL strings for each migration.
// The .sql files alongside this file are the canonical reference; these strings
// must stay in sync with them.

export interface Migration {
  name: string;
  sql: string;
}

const MIGRATION_001 = `
CREATE TABLE IF NOT EXISTS users (
  id           TEXT PRIMARY KEY,
  display_name TEXT NOT NULL DEFAULT '',
  default_unit TEXT NOT NULL DEFAULT 'kg',
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS exercises (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  normalized_name TEXT NOT NULL,
  category        TEXT NOT NULL CHECK (category IN ('barbell','dumbbell','machine','bodyweight','cable','other')),
  primary_muscle  TEXT,
  default_unit    TEXT CHECK (default_unit IN ('kg','lb')),
  is_custom       INTEGER NOT NULL DEFAULT 0,
  archived_at     INTEGER,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_exercises_normalized_name ON exercises (normalized_name);
CREATE INDEX IF NOT EXISTS idx_exercises_archived        ON exercises (archived_at);

CREATE TABLE IF NOT EXISTS exercise_aliases (
  id          TEXT PRIMARY KEY,
  exercise_id TEXT NOT NULL REFERENCES exercises(id),
  alias       TEXT NOT NULL UNIQUE,
  source      TEXT NOT NULL DEFAULT 'seed' CHECK (source IN ('seed','user')),
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_aliases_alias    ON exercise_aliases (alias);
CREATE INDEX IF NOT EXISTS idx_aliases_exercise ON exercise_aliases (exercise_id);

CREATE TABLE IF NOT EXISTS templates (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  notes       TEXT,
  archived_at INTEGER,
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS template_items (
  id            TEXT PRIMARY KEY,
  template_id   TEXT NOT NULL REFERENCES templates(id),
  exercise_id   TEXT NOT NULL REFERENCES exercises(id),
  position      INTEGER NOT NULL,
  target_sets   INTEGER,
  target_reps   INTEGER,
  target_weight REAL,
  target_rpe    REAL,
  UNIQUE (template_id, position)
);

CREATE TABLE IF NOT EXISTS workout_sessions (
  id                  TEXT PRIMARY KEY,
  template_id         TEXT REFERENCES templates(id),
  name                TEXT,
  status              TEXT NOT NULL CHECK (status IN ('in_progress','completed','discarded')),
  started_at          INTEGER NOT NULL,
  ended_at            INTEGER,
  total_volume_cached REAL,
  created_at          INTEGER NOT NULL,
  updated_at          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_status  ON workout_sessions (status);
CREATE INDEX IF NOT EXISTS idx_sessions_started ON workout_sessions (started_at DESC);

CREATE TABLE IF NOT EXISTS workout_events (
  id              TEXT PRIMARY KEY,
  session_id      TEXT NOT NULL REFERENCES workout_sessions(id),
  event_type      TEXT NOT NULL,
  payload_json    TEXT NOT NULL,
  client_event_id TEXT NOT NULL UNIQUE,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_session_created ON workout_events (session_id, created_at);

CREATE TABLE IF NOT EXISTS workout_sets (
  id            TEXT PRIMARY KEY,
  session_id    TEXT NOT NULL REFERENCES workout_sessions(id),
  exercise_id   TEXT NOT NULL REFERENCES exercises(id),
  position      INTEGER NOT NULL,
  weight        REAL,
  reps          INTEGER,
  rpe           REAL,
  unit          TEXT NOT NULL DEFAULT 'kg',
  is_warmup     INTEGER NOT NULL DEFAULT 0,
  logged_at     INTEGER NOT NULL,
  source        TEXT NOT NULL DEFAULT 'tap',
  client_set_id TEXT NOT NULL UNIQUE,
  deleted_at    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_sets_session         ON workout_sets (session_id, position);
CREATE INDEX IF NOT EXISTS idx_sets_exercise_logged ON workout_sets (exercise_id, logged_at DESC);

CREATE TABLE IF NOT EXISTS exercise_history_cache (
  exercise_id          TEXT PRIMARY KEY REFERENCES exercises(id),
  last_session_id      TEXT,
  last_session_at      INTEGER,
  last_top_set_weight  REAL,
  last_top_set_reps    INTEGER,
  last_session_volume  REAL,
  est_1rm              REAL,
  recent_sessions_json TEXT,
  updated_at           INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS post_session_tags (
  id         TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES workout_sessions(id),
  tag        TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  UNIQUE (session_id, tag)
);

CREATE TABLE IF NOT EXISTS session_notes (
  session_id    TEXT PRIMARY KEY REFERENCES workout_sessions(id),
  energy_rating INTEGER,
  note          TEXT,
  updated_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS metric_samples (
  id         TEXT PRIMARY KEY,
  metric_key TEXT NOT NULL,
  value_num  REAL,
  value_text TEXT,
  sampled_at INTEGER NOT NULL,
  source     TEXT NOT NULL DEFAULT 'workout',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_metric_key_sampled ON metric_samples (metric_key, sampled_at DESC);

CREATE TABLE IF NOT EXISTS weekly_insight_cards (
  id                       TEXT PRIMARY KEY,
  generated_for_week_start INTEGER NOT NULL UNIQUE,
  title                    TEXT NOT NULL,
  body                     TEXT NOT NULL,
  sample_size              INTEGER NOT NULL,
  confidence_label         TEXT NOT NULL CHECK (confidence_label IN ('low','medium','high')),
  payload_json             TEXT,
  dismissed_at             INTEGER,
  created_at               INTEGER NOT NULL
);
`;

const MIGRATION_002 = `
CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
`;

const MIGRATION_003 = `
CREATE TABLE IF NOT EXISTS exercise_metadata (
  exercise_id            TEXT PRIMARY KEY REFERENCES exercises(id),
  movement_pattern       TEXT,
  force_type             TEXT CHECK (force_type IN ('push','pull','legs','hinge','core','carry','mixed','other')),
  body_region            TEXT,
  primary_muscles_json   TEXT NOT NULL DEFAULT '[]',
  secondary_muscles_json TEXT NOT NULL DEFAULT '[]',
  equipment_json         TEXT NOT NULL DEFAULT '[]',
  mechanics              TEXT CHECK (mechanics IN ('compound','isolation','other')),
  laterality             TEXT CHECK (laterality IN ('bilateral','unilateral','alternating','single_side','other')),
  difficulty             INTEGER,
  substitution_group     TEXT,
  source                 TEXT NOT NULL DEFAULT 'curated_seed',
  source_id              TEXT,
  updated_at             INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_exercise_metadata_force_type
  ON exercise_metadata (force_type);
CREATE INDEX IF NOT EXISTS idx_exercise_metadata_movement_pattern
  ON exercise_metadata (movement_pattern);
CREATE INDEX IF NOT EXISTS idx_exercise_metadata_body_region
  ON exercise_metadata (body_region);
CREATE INDEX IF NOT EXISTS idx_exercise_metadata_substitution_group
  ON exercise_metadata (substitution_group);
`;

const MIGRATION_004 = `
CREATE INDEX IF NOT EXISTS idx_exercise_metadata_mechanics
  ON exercise_metadata (mechanics);

CREATE INDEX IF NOT EXISTS idx_exercise_metadata_laterality
  ON exercise_metadata (laterality);
`;

const MIGRATION_005 = `
CREATE INDEX IF NOT EXISTS idx_exercise_metadata_source_source_id
  ON exercise_metadata (source, source_id);
`;

const MIGRATION_006 = `
ALTER TABLE workout_sets
  ADD COLUMN set_type TEXT NOT NULL DEFAULT 'working'
  CHECK (set_type IN ('warmup','working','drop'));
`;

const MIGRATION_007 = `
CREATE TABLE IF NOT EXISTS exercise_prs (
  id          TEXT PRIMARY KEY,
  exercise_id TEXT NOT NULL REFERENCES exercises(id),
  session_id TEXT NOT NULL REFERENCES workout_sessions(id),
  set_id      TEXT REFERENCES workout_sets(id),
  record_type TEXT NOT NULL CHECK (record_type IN ('rep_max','estimated_1rm','session_volume')),
  record_key  TEXT NOT NULL,
  reps        INTEGER,
  weight      REAL,
  value       REAL NOT NULL,
  unit        TEXT NOT NULL DEFAULT 'kg',
  achieved_at INTEGER NOT NULL,
  created_at  INTEGER NOT NULL,
  UNIQUE (exercise_id, session_id, record_key)
);
CREATE INDEX IF NOT EXISTS idx_exercise_prs_exercise_id ON exercise_prs (exercise_id);
CREATE INDEX IF NOT EXISTS idx_exercise_prs_session_id ON exercise_prs (session_id);
CREATE INDEX IF NOT EXISTS idx_exercise_prs_record_type ON exercise_prs (record_type);
CREATE INDEX IF NOT EXISTS idx_exercise_prs_achieved_at ON exercise_prs (achieved_at DESC);
`;

const MIGRATION_008 = `
ALTER TABLE template_items
  ADD COLUMN rest_seconds INTEGER
  CHECK (rest_seconds IS NULL OR rest_seconds > 0);
`;

const MIGRATION_009 = `
ALTER TABLE template_items
  ADD COLUMN progression_rule TEXT NOT NULL DEFAULT 'none'
  CHECK (progression_rule IN ('none','linear','double','rpe_gated'));

ALTER TABLE template_items
  ADD COLUMN increment_kg REAL;

ALTER TABLE template_items
  ADD COLUMN increment_lb REAL;

ALTER TABLE template_items
  ADD COLUMN rep_range_min INTEGER
  CHECK (rep_range_min IS NULL OR rep_range_min > 0);

ALTER TABLE template_items
  ADD COLUMN rep_range_max INTEGER
  CHECK (rep_range_max IS NULL OR rep_range_max > 0);

ALTER TABLE template_items
  ADD COLUMN rpe_cap REAL
  CHECK (rpe_cap IS NULL OR (rpe_cap >= 1 AND rpe_cap <= 10));
`;

const MIGRATION_010 = `
ALTER TABLE template_items
  ADD COLUMN amrap_last_set INTEGER NOT NULL DEFAULT 0
  CHECK (amrap_last_set IN (0, 1));
`;

const MIGRATION_011 = `
CREATE TRIGGER IF NOT EXISTS trg_workout_sessions_one_in_progress_insert
BEFORE INSERT ON workout_sessions
WHEN NEW.status = 'in_progress'
  AND EXISTS (
    SELECT 1 FROM workout_sessions WHERE status = 'in_progress'
  )
BEGIN
  SELECT RAISE(ABORT, 'only one in-progress workout session is allowed');
END;

CREATE TRIGGER IF NOT EXISTS trg_workout_sessions_one_in_progress_update
BEFORE UPDATE OF status ON workout_sessions
WHEN NEW.status = 'in_progress'
  AND OLD.status <> 'in_progress'
  AND EXISTS (
    SELECT 1 FROM workout_sessions
    WHERE status = 'in_progress' AND id <> NEW.id
  )
BEGIN
  SELECT RAISE(ABORT, 'only one in-progress workout session is allowed');
END;
`;

const MIGRATION_012 = `
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_in_progress_session
  ON workout_sessions(status)
  WHERE status = 'in_progress';
`;

const MIGRATION_013 = `
ALTER TABLE exercise_metadata
  ADD COLUMN tertiary_muscles_json TEXT NOT NULL DEFAULT '[]';
`;

const MIGRATION_014 = `
CREATE TABLE IF NOT EXISTS issues (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  note       TEXT,
  active     INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_issues_active ON issues (active);

CREATE TABLE IF NOT EXISTS exercise_issue_events (
  id            TEXT PRIMARY KEY,
  issue_id      TEXT NOT NULL REFERENCES issues(id),
  exercise_id   TEXT NOT NULL REFERENCES exercises(id),
  session_id    TEXT REFERENCES workout_sessions(id),
  reaction_type TEXT NOT NULL CHECK (reaction_type IN ('aggravated','helped')),
  severity      INTEGER CHECK (severity IS NULL OR (severity >= 1 AND severity <= 5)),
  note          TEXT,
  created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_exercise_issue_events_issue_created
  ON exercise_issue_events (issue_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exercise_issue_events_exercise_created
  ON exercise_issue_events (exercise_id, created_at DESC);
`;

const MIGRATION_015 = `
CREATE TABLE IF NOT EXISTS issue_exercise_links (
  id          TEXT PRIMARY KEY,
  issue_id    TEXT NOT NULL REFERENCES issues(id),
  exercise_id TEXT NOT NULL REFERENCES exercises(id),
  link_type   TEXT NOT NULL CHECK (link_type IN ('helpful','aggravating')),
  note        TEXT,
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  UNIQUE (issue_id, exercise_id, link_type)
);
CREATE INDEX IF NOT EXISTS idx_issue_exercise_links_issue
  ON issue_exercise_links (issue_id);
CREATE INDEX IF NOT EXISTS idx_issue_exercise_links_exercise
  ON issue_exercise_links (exercise_id);
`;

const MIGRATION_016 = `
ALTER TABLE template_items
  ADD COLUMN note TEXT;
`;

const MIGRATION_017 = `
CREATE TABLE IF NOT EXISTS issue_routines (
  id          TEXT PRIMARY KEY,
  issue_id    TEXT NOT NULL REFERENCES issues(id),
  template_id TEXT NOT NULL REFERENCES templates(id),
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  UNIQUE (issue_id)
);
CREATE INDEX IF NOT EXISTS idx_issue_routines_issue
  ON issue_routines (issue_id);
CREATE INDEX IF NOT EXISTS idx_issue_routines_template
  ON issue_routines (template_id);
`;

const MIGRATION_018 = `
CREATE TABLE IF NOT EXISTS issue_checkins (
  id         TEXT PRIMARY KEY,
  issue_id   TEXT NOT NULL REFERENCES issues(id),
  severity   INTEGER NOT NULL CHECK (severity >= 1 AND severity <= 5),
  note       TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_issue_checkins_issue_created
  ON issue_checkins (issue_id, created_at DESC);
`;

const MIGRATION_019 = `
ALTER TABLE templates
  ADD COLUMN program_preset_id TEXT;

ALTER TABLE templates
  ADD COLUMN is_active_programme INTEGER NOT NULL DEFAULT 0
  CHECK (is_active_programme IN (0, 1));

CREATE INDEX IF NOT EXISTS idx_templates_program_preset
  ON templates (program_preset_id);

CREATE UNIQUE INDEX IF NOT EXISTS idx_one_active_programme
  ON templates(is_active_programme)
  WHERE is_active_programme = 1;
`;

export const MIGRATIONS: Migration[] = [
  { name: '001_init', sql: MIGRATION_001 },
  { name: '002_app_settings', sql: MIGRATION_002 },
  { name: '003_exercise_metadata', sql: MIGRATION_003 },
  { name: '004_exercise_metadata_filter_indexes', sql: MIGRATION_004 },
  { name: '005_exercise_metadata_source_index', sql: MIGRATION_005 },
  { name: '006_workout_set_type', sql: MIGRATION_006 },
  { name: '007_exercise_prs', sql: MIGRATION_007 },
  { name: '008_template_item_rest_seconds', sql: MIGRATION_008 },
  { name: '009_template_item_progression_rules', sql: MIGRATION_009 },
  { name: '010_template_item_amrap_last_set', sql: MIGRATION_010 },
  { name: '011_one_in_progress_session', sql: MIGRATION_011 },
  { name: '012_one_in_progress_session_unique_index', sql: MIGRATION_012 },
  { name: '013_exercise_metadata_tertiary_muscles', sql: MIGRATION_013 },
  { name: '014_issues', sql: MIGRATION_014 },
  { name: '015_issue_exercise_links', sql: MIGRATION_015 },
  { name: '016_template_item_note', sql: MIGRATION_016 },
  { name: '017_issue_routines', sql: MIGRATION_017 },
  { name: '018_issue_checkins', sql: MIGRATION_018 },
  { name: '019_active_programme', sql: MIGRATION_019 },
];
